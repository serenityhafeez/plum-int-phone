import intlTelInput from "../intl-tel-input";
import utils from "./utils-compiled";
intlTelInput.utils = utils;
export default intlTelInput;