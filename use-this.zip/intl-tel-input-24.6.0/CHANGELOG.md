See the Github Releases page for changelog: https://github.com/jackocnr/intl-tel-input/releases

Or to lookup a specific version, e.g. v20.0.0, update the URL accordingly: https://github.com/jackocnr/intl-tel-input/releases/tag/v20.0.0
