import { createApp } from "vue";
import App from "./App.vue";
import "../../../build/css/intlTelInput.css";
import "../../../build/css/demo.css";

createApp(App).mount("#app");
